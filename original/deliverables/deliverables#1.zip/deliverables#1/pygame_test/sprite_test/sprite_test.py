
# http://stackoverflow.com/questions/14044147/animated-sprite-from-few-images

# function structure / fn names / python module use / 
# of __init__, load_image, update, my_group
# based upon online tutorial

# all other fn's were solo 


import pygame
import sys

def load_image(name):
    image = pygame.image.load(name)
    return image

class TestSprite(pygame.sprite.Sprite):
    def __init__(self, fps=10):
        super(TestSprite, self).__init__()
        self.load_images()
        #self.load_rects()
        self.start = pygame.time.get_ticks()
        self.delay = 1000/fps
        self.last_update = 0
        self.frame = 0
        self.bg_color = load_image('bg_image.png')
        self.move = "run"
        self.dir = "right"
        self.angle = "_90"

    def makeBoundingBoxes(self):
        # crouch (left / right/ 0, 45...)  stand, run....
        # fill out manually
        # center 'origin' at center of 'sprite dim' in relation to window dim
        #self.boundingBoxes = [ [], [], ......]
        pass

    def load_rects(self):
        coords = self.makeBoundingBoxes()
        self.boundingBoxes = dict()
        for i in xrange(len(self.images)):
            sprite_image = self.images[i]
            boundingBox = boundingBoxes[i]
            self.boundingBoxes[sprite_image] = pygame.Rect(coords[i])

    def load_images(self):
        self.images = dict()
        bg_image = 'bg_image.png'
        for move in xrange(5):
            moves = ['crouch', 'stand', 'run', 'jump', 'fall', 'switch']
            if (moves[move] == 'switch'):
                for secondary_move in xrange(3):
                    secondary_moves = ['crouch', 'jump', 'stand']
                    for dir in xrange(2):
                        dirs = ['left', 'right']
                        for angle in xrange(6):
                            angles = ['', '_0', '_45', '_90', '_135', '_180']
                            current_image = "%s_%s%s.png" % (secondary_moves[secondary_move], dirs[dir], angles[angle])
                            try:
                                self.images[current_image] = load_image(current_image)
                            except:
                                pass
            else:
                for dir in xrange(2):
                    dirs = ['left', 'right']
                    for angle in xrange(6):
                        angles = ['', '_0', '_45', '_90', '_135', '_180']
                        current_image = "%s_%s%s.png" % (moves[move], dirs[dir], angles[angle])
                        try:
                            self.images[current_image] = load_image(current_image)
                        except:
                            pass
        self.rect = pygame.Rect(50,50,100,100)

    def update(self, t):
        # needs to be updated for mouse input
        delta = t - self.last_update
        if (delta > self.delay):
            self.updateMovement()

    def updateMovement(self):
        user_input = "%s_%s%s.png" % (self.move, self.dir, self.angle)
        self.image = self.images[user_input]

    def keyEvent(self, event):
        # arrow keys --> move
        # wasd --> look
        
        if event.key == pygame.K_COMMA:
            self.angle = ''
            self.move = "run"
        elif event.key == pygame.K_PERIOD:
            self.move = "crouch"
   
        elif event.key == pygame.K_SLASH:
            self.move = "jump"
            if self.angle == '':
                self.angle = '_90'
        else:
            self.move_dir = 0
            if self.angle == '':
                self.angle = '_90'
            self.move = "stand"

        if (event.key == pygame.K_w):
            if (self.move == 'jump') or (self.move == 'fall') or (self.move == 'stand'):
                self.angle = "_0"
        elif (event.key == pygame.K_s):
            if (self.move == 'jump') or (self.move == 'fall'):
                self.angle = "_180"
        elif (event.key == pygame.K_a):
            self.angle = "_90"
            self.dir = "left"
        elif (event.key == pygame.K_d):
            self.angle = "_90"
            self.dir = "right"


        keys_pressed = pygame.key.get_pressed()
        if keys_pressed[pygame.K_w] and keys_pressed[pygame.K_a]:
            self.angle = "_45"
            self.dir = "left"
        elif keys_pressed[pygame.K_w] and keys_pressed[pygame.K_d]:
            self.angle = "_45"
            self.dir = "right"
        if keys_pressed[pygame.K_s] and keys_pressed[pygame.K_a]:
            self.angle = "_135"
            self.dir = "left"
        elif keys_pressed[pygame.K_s] and keys_pressed[pygame.K_d]:
            self.angle = "_135"
            self.dir = "right"



def main(width, height):
    screen = pygame.display.set_mode((width, height))
    pygame.init()

    my_sprite = TestSprite()
    my_group = pygame.sprite.Group(my_sprite)

    pygame.key.get_repeat()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit(0)
            elif event.type == pygame.KEYDOWN:
                my_sprite.keyEvent(event)


        # Calling the 'my_group.update' function calls the 'update' function of all 
        # its member sprites. Calling the 'my_group.draw' function uses the 'image'
        # and 'rect' attributes of its member sprites to draw the sprite.
        my_group.update(pygame.time.get_ticks())
        my_group.clear(screen, my_sprite.bg_color)
        my_group.draw(screen)
        pygame.display.flip()


if __name__ == '__main__':
    main(150, 150)