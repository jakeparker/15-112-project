
# fn naming nomenclature, and use of some pygame modules
# influenced from online tutorial (referrenced in spite_test.py)

# player_animation.py is based off of sprite_test.py,
# all code below was re-written solo


######################################

# stand move is broken b/c I did not differentiate placeholder sprites (used in left-right transition)
# from the sprites for each individual move

# comma --> run animation
# period --> stand
# slash --> jump animation
# up --> crouch animation

# wasd --> look
# f --> switch missile/laser

# space --> fire weapon

# type pathway to /deliverable_1/sprites   in line 16 before running

import pygame
import sys

def load_image(fileName):
	pathway = '/Users/Jake/CMU/15-112/Term_Project/Deliverables/deliverable_1/sprites/samus/'
	return pygame.image.load(pathway + fileName + ".png")


class Samus(pygame.sprite.Sprite):
	def __init__(self, width, height, fps=10):
		super(Samus, self).__init__()
		self.bg_color = load_image("bg_color")
		self.screenWidth = width
		self.screenHeight = height
		self.load_moves()
		self.load_images()
		self.load_rects()
		self.fired = False
		self.switch = False
		self.delay = 1000/fps
		self.last_update = 0
		self.frame = 0
		self.weapons = ['missile', 'laser']
		self.weaponIndex = 0
		self.sprite_input = "run_stand_laser_90_0"
		self.move = 'stand'
		self.dir = 'right'
		self.weapon = 'laser'
		self.angle = '90'
		self.frame = '0'

	def load_moves(self):
		# move_dir_weapon_angle_num                              # stand, crouch, jump, land, run, morph, spin
		# stand:  4 frames + fire   0, 45, 90, 135               # left, right
		# crouch: 2 frames + fire      45, 90, 135               # missile, laser, empty
		# jump:   4 frames + 180     0, 45, 90, 135, 180         # 0, 45, 90, 135, 180
		# land:   1 frame            0, 45, 90, 135
		# run:    10 frames              45, 90, 135       weapon -/-> empty
		# morph:  10 frame        90            weapon --> empty
		# spin:   9 frames        90            weapon --> empty
		(width, height) = (self.screenWidth, self.screenHeight)
		self.dirs = ['left', 'right']
		self.stand =  [ 'stand', 3, ['0', '45', '90', '135'], ['missile', 'laser'] ]
		self.crouch = [ 'crouch', 1, ['45', '90', '135'], ['missile', 'laser'] ]
		self.jump =   [ 'jump', 4, ['0', '45', '90', '135'], ['missile', 'laser'] ]
		self.fall =   [ 'jump', 1, ['180'], ['missile', 'laser'] ]
		self.land =   [ 'land', 1, ['0', '45', '90', '135'], ['missile', 'laser'] ]
		self.run =    [ 'run', 10, ['45', '90', '135'], ['missile', 'laser'] ]
		self.freeRun = [ 'run', 10, ['90'], ['missile', 'empty'] ]
		self.morph =  [ 'morph', 9, ['90'], ['empty'] ]
		self.spin =   [ 'spin', 8, ['90'], ['empty'] ]
		self.crouchFire = [ 'crouch', 1, ['45', '90', '135'], ['missile', 'laser'] ]
		self.standFire = [ 'stand', 1, ['0', '45', '90', '135'], ['missile', 'laser'] ]
		self.moves = [self.stand, self.crouch, self.jump, self.fall, self.land, self.run, self.freeRun, self.morph, self.spin, self.standFire, self.crouchFire]
		self.rect = pygame.Rect(width/2-40, height/2-40, width/2+40, height/2+40)
	
	def load_images(self):
		self.images = dict()
		for moveList in self.moves:
			move = moveList[0]
			frames = moveList[1]
			angles = moveList[2]
			weapons = moveList[3]
			for dir in self.dirs:
				for angle in angles:
					for weapon in weapons:
						for frame in xrange(frames):
							if (moveList == self.standFire) or (moveList == self.crouchFire):
								frame = 'fire'
							current_image = "%s_%s_%s_%s_%s" % (move, dir, weapon, angle, frame)
							self.images[current_image] = (load_image(current_image), moveList)






					### ADD move_dir_angle_SWITCH   instead of #0 for (stand, jump,)




	def keyEvent(self, event):
		# wasd keys --> look
		# hold comma --> run
		# hold period --> crouch
		# slash --> jump
		self.switch = False
		self.checkLook(event)
		self.checkStance(event)
		self.checkWeapon(event)

	def checkLook(self, event):
		if (event.key == pygame.K_w):
			if (self.move == 'jump') or (self.move == 'stand'):
				self.angle = "0"
		elif (event.key == pygame.K_s):
			if (self.move == 'jump'):
				self.angle = "180"
		elif (event.key == pygame.K_a):
			if (self.dir == "left"):
				self.angle = "90"
			else:
				self.dir = "left"
				self.switch = True
		elif (event.key == pygame.K_d):
			if (self.dir == "right"):
				self.angle = "90"
			else:
				self.dir = "right"
				self.switch = True

		isPressed = pygame.key.get_pressed()
		if isPressed[pygame.K_w] and isPressed[pygame.K_a]:
			self.angle = "45"
		elif isPressed[pygame.K_w] and isPressed[pygame.K_d]:
			self.angle = "45"
		elif isPressed[pygame.K_s] and isPressed[pygame.K_a]:
			self.angle = "135"
		elif isPressed[pygame.K_s] and isPressed[pygame.K_d]:
			self.angle = "135"

	def checkStance(self, event):
		isPressed = pygame.key.get_pressed()
		if isPressed[pygame.K_COMMA]:
			self.move = "run"
		elif isPressed[pygame.K_PERIOD]:
			self.move = "stand"
		if isPressed[pygame.K_UP]:
			self.move = "crouch"
		elif isPressed[pygame.K_SLASH]:
			self.move = "jump"

	def checkWeapon(self, event):
		if (event.key == pygame.K_SPACE):
			#weapon.updateWeapon()
			pass
		if (event.key == pygame.K_f):
			self.weaponIndex += 1
			self.weaponIndex %= len(self.weapons)
			self.weapon = self.weapons[self.weaponIndex]

	def load_rects(self):
		pass


	def update(self, current_update):
		####### BUG #########
		timeElapsed = current_update - self.last_update
		if (timeElapsed > self.delay):
			self.updateMovement()
			self.last_update = current_update

	def updateMovement(self):
		move = self.move
		dir = self.dir
		weapon = self.weapon
		angle = self.angle
		current_image = "%s_%s_%s_%s_0" % (move, dir, weapon, angle)
		moveList = self.images[current_image][1]
		frames = moveList[1]
		frame = int(self.frame)
		frame += 1
		frame %= frames
		frame = str(frame)
		self.frame = frame
		sprite_input = "%s_%s_%s_%s_%s" % (move, dir, weapon, angle, frame)
		self.image = self.images[sprite_input][0]

class Weapon(pygame.sprite.Sprite):
	def __init__(self, fps=10):
		super(Weapon, self).__init__()
		self.load_weapons()
		self.load_images()
		self.load_rects()
		self.fired = False
		self.impact = False
		self.last_update = 0
		self.frame = 0
		self.weapon_input = "laser_right_power_flight_90_0"

	def load_weapons(self):
		self.dirs = ['left', 'right']
		self.laserFire = [ 'laser', 'fire', 2, ['power'] ]
		self.laserFlight = [ 'laser', 'flight', 2 ['0', '45', '90', '135', '180'], ['power'] ]
		self.missileFlight = [ 'missile', 'flight', 2, ['0', '45', '90', '135', '180'], ['regular'] ]
		self.laserImpact = [ 'laser', 'impact', 4, ['power'] ]
		self.missileImpact = [ 'missile', 'impact', 5, ['regular'] ]
		self.fire = [self.laserFire]
		self.flight = [self.laserFlight, self.missileFlight]
		self.impact = [self.laserImpact, self.missileImpact]

	def load_images(self):
		self.images = dict()
		self.load_fire_animation()
		self.load_flight_animation()
		self.load_impact_animation()

	def load_fire_animation(self):
		for animation in self.fire:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			versions = animation[3]
			for version in versions:
				for frame in frames:
					current_image = "%s_%s_%s_%s" % (weapon, version, action, frame)
					self.images[current_image] = load_image(current_image)

	def load_flight_animation(self):
		for animation in self.flight:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			angles = animation[3]
			versions = animation[4]
			for dir in self.dirs:
				for version in versions:
					for angle in angles:
						for frame in frames:
							current_image = "%s_%s_%s_%s_%s" % (weapon, dir, version, angle, frame)
							self.images[current_image] = load_image(current_image)

	def load_impact_animation(self):
		for animation in self.impact:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			versions = animation[3]
			for version in versions:
				for frame in frames:
					current_image = "%s_%s_%s_%s" % (weapon, version, action, frame)
					self.images[current_image] = load_image(current_image)

	def load_rects(self):
		pass

	def updateWeapon(self):
		move = self.move
		dir = self.dir
		weapon = self.weapon
		angle = self.angle
		if (move == 'stand') or (move == "crouch"):
			self.updateRecoil(move, dir, weapon, angle)
		current_image = "%s_%s_%s_%s_0" % (move, dir, weapon, angle)
		moveList = self.images[current_image][1]
		frames = moveList[1]
		frame = int(self.frame)
		frame += 1
		frame %= frames
		frame = str(frame)
		self.frame = frame
		weapon_input = "%s_%s_%s_%s_%s" % (move, dir, weapon, angle, frame)
		self.image = self.images[weapon_input][0]

def load_Sprites():
	### not expandable ###
	player = Samus()
	#weapon = Weapon()

def main(width, height):
	screen = pygame.display.set_mode((width, height))
	pygame.init()
	#load_sprites()
	pygame.key.set_repeat(50,50)
	player = Samus(width, height)
	#weapon = Weapon()
	### how does sprite.Group work???
	activeSprites = pygame.sprite.Group(player)


	
	while True:
		pygame.key.get_repeat()
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit(0)
			elif event.type == pygame.KEYDOWN:
				player.keyEvent(event)
		activeSprites.update(pygame.time.get_ticks())
		activeSprites.clear(screen, player.bg_color)
		activeSprites.draw(screen)
		pygame.display.flip()




if __name__ == '__main__':
	main(300,340)