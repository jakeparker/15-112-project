import pygame
import numpy

class Weapon(pygame.sprite.Sprite):
	def __init__(self, fps=10):
		super(Weapon, self).__init__()
		self.load_weapons()
		self.load_images()
		self.load_rects()
		self.fired = False
		self.impact = False
		self.last_update = 0
		self.frame = 0
		self.weapon_input = 'laser_right_power_flight_90_0'

	def load_weapons(self):
		self.dirs = ['left', 'right']
		self.laserFire = [ 'laser', 'fire', 2, ['power'] ]
		self.laserFlight = [ 'laser', 'flight', 2 ['0', '45', '90', '135', '180'], ['power'] ]
		self.missileFlight = [ 'missile', 'flight', 2, ['0', '45', '90', '135', '180'], ['regular'] ]
		self.laserImpact = [ 'laser', 'impact', 4, ['power'] ]
		self.missileImpact = [ 'missile', 'impact', 5, ['regular'] ]
		self.fire = [self.laserFire]
		self.flight = [self.laserFlight, self.missileFlight]
		self.impact = [self.laserImpact, self.missileImpact]

	def load_images(self):
		pathway = '/sprites/weapons/'
		self.images = dict()
		self.load_fire_animation()
		self.load_flight_animation()
		self.load_impact_animation()

	def load_fire_animation(self):
		for animation in self.fire:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			versions = animation[3]
			for version in versions:
				for frame in frames:
					current_image = "%s_%s_%s_%s" % (weapon, version, action, frame)
					self.images[current_image] = load_image(current_image)

	def load_flight_animation(self):
		for animation in self.flight:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			angles = animation[3]
			versions = animation[4]
			for dir in self.dirs:
				for version in versions:
					for angle in angles:
						for frame in frames:
							current_image = "%s_%s_%s_%s_%s" % (weapon, dir, version, angle, frame)
							self.images[current_image] = load_image(current_image)

	def load_impact_animation(self):
		for animation in self.impact:
			weapon = animation[0]
			action = animation[1]
			frames = animation[2]
			versions = animation[3]
			for version in versions:
				for frame in frames:
					current_image = "%s_%s_%s_%s" % (weapon, version, action, frame)
					self.images[current_image] = load_image(current_image)

	def load_rects(self):
		pass

	def update(self):
		self.updateWeapon()

	def updateWeapon(self):
		move = self.move
		dir = self.dir
		weapon = self.weapon
		angle = self.angle
		if (move == 'stand') or (move == "crouch"):
			self.updateRecoil(move, dir, weapon, angle)
		current_image = "%s_%s_%s_%s_0" % (move, dir, weapon, angle)
		moveList = self.images[current_image][1]
		frames = moveList[1]
		frame = int(self.frame)
		frame += 1
		frame %= frames
		frame = str(frame)
		self.frame = frame
		weapon_input = "%s_%s_%s_%s_%s" % (move, dir, weapon, angle, frame)
		self.image = self.images[weapon_input][0]