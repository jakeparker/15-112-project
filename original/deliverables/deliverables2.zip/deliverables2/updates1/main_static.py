import pygame
import numpy
from load_sprite_classes import *
import sys

class Main(object):
	def __init__(self):
		self.name = 'Main'

	def load_map(self):
		pathway = '/sprites/maps/'
		self.map0 = load_image('map0', pathway)
		self.map0_rect = self.map0.get_rect()
		map0_mask = load_image('map0_mask', pathway)
		self.map0_mask = pygame.surfarray.pixels3d(map0_mask)
	def load_colorKey(self):
		black = (0,0,0)         # out of bounds
		green = (0,249,0)       # wall segment
		cyan = (0,253,255)      # playable area
		blue = (4,51,255)       # overlay
		magenta = (255,64,255)  # door lockd
		purple = (148,33,146)  # door passage
		orange = (255,147,0)    # elevator pad
		self.colorKey = [cyan, green, black, blue, magenta, purple, orange]

	def load_sprites(self):
		self.player = Samus(self.screen, self.map0_mask, 1411, 132)
		self.SpriteGroup = pygame.sprite.Group()
		self.SpriteGroup.add(self.player)

	def run(self):
		pygame.init()
		self.load_map()
		self.screen = pygame.display.set_mode(self.map0.get_size())
		pygame.display.set_caption("Metroid Fusion")
		self.load_colorKey()
		self.load_sprites()
		self.screen.blit(self.map0, self.map0_rect)

		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit(0)
				elif event.type == pygame.KEYDOWN:
					self.player.keyEvent(event)
			rect = self.player.rect
			self.SpriteGroup.update(pygame.time.get_ticks())
			self.SpriteGroup.clear(self.screen, self.map0)
			self.SpriteGroup.draw(self.screen)
			pygame.display.update()


if __name__ == '__main__':
	game = Main()
	game.run()

